<template>
  <h1>Welcome to FixMyRide</h1>
</template>

<script setup>
</script>

<style scoped>
h1 {
  color: #42b983;
}
</style>
